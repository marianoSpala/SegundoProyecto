# Documentación de la API Segundo Proyecto Integrador
### Spala Mariano - Argentina Programa 4.0 - Backend, lu y mie 9 a 11 hs.

El objetivo de este documento es explicar las operaciones básicas que se pueden realizar sobre la base de datos "computacion" con la API "Segundo Proyecto Integrador".

## Índice de contenidos

- 1 [CRUD](#crud)
 - 1.1 [Create](#create)
 - 1.2 [Read](#read)
 - 1.3 [Update](#update)
 - 1.4 [Delete](#delete)
- 2 [Tabla URL](#tabla-url)
- 3 [Ejemplos de uso](#ejemplos-de-uso)
 - 3.1 [Ejemplo de uso del método POST](#ejemplo-de-uso-del-método-post)
 - 3.2 [Ejemplo de uso del método GET](#ejemplo-de-uso-del-método-get)
 - 3.3 [Ejemplo de uso del método PUT](#ejemplo-de-uso-del-método-put)
 - 3.4 [Ejemplo de uso del método DELETE](#ejemplo-de-uso-del-método-delete)
- 4 [Conexión a Mongodb](#conexión-a-mongodb)
- 5 [Diagrama de Secuencia](#diagrama-de-secuencia)
- 6 [Diagrama de flujo](#diagrama-de-flujo)
- 7 [Listado de Errores](#listado-de-errores)


## Tabla URL

| URL                          | Descripción                                                                | Método |
|------------------------------|----------------------------------------------------------------------------|:------:|
|http://localhost:3008/               |URL o ruta principal.                                                |  GET   |
|http://localhost:3008/computacion    |URL general para visualizar todos los productos.                     |  GET   |
|http://localhost:3008/computacion/:codigo |URL que nos retorna un producto por su código.                  |  GET   |
|http://localhost:3008/computacion/nombre/:nombre |URL que nos retorna  producto/s por nombre.              |  GET   |
|http://localhost:3008/computacion/categoria/:categoria |URL que nos retorna  producto/s por categoría.     |  GET   |
|http://localhost:3008/computacion/precio/:precio |URL que nos retorna  producto/s de precio igual y superior al precio pasado por parámetro.                                                                                                  |  GET  |
|http://localhost:3008/computacion         |URL que nos permite dar de alta un recurso.                     |  POST  |
|http://localhost:3008/computacion/:codigo |URL que nos permite modificar un recurso existente.             |  PUT   |
|http://localhost:3008/computacion/:codigo |URL que nos permite eliminar un recurso existente.              | DELETE |
| 




## CRUD
El término CRUD es un acrónimo que se utiliza en el mundo de la programación para describir las operaciones básicas que se pueden realizar sobre una base de datos.

CRUD significa "Create, Read, Update, Delete"
(Crear, Leer, Actualizar y Borrar, respectivamente).

El término CRUD es conocido en español como ABM (Alta, Baja y Modificación) de datos en una base de datos.

Se explica a continuación como llevar a cabo estas  operaciones dentro del contexto de la presente API:

### 'Create'
### El método POST
Este método nos permite crear un nuevo artículo, el cual se agregara al listado de objetos en la base de datos.
Es necesario completar el ***Body*** de la petición con los datos del artículo a crear.

#### El ***Body*** de la petición POST
Es aqui donde se vuelcan los datos del artículo nuevo.
El cuerpo de los datos bebe estar entre llaves,
el nombre de los atributos del artículo va entre comillas y para asignar el valor correspondiente a éstos se utilizan los dos puntos (:) luego del nombre.
Por ejemplo:

```js
  {
    "codigo": 8,
    "nombre": "Disco Duro Externo",
    "precio": 99.99,
    "categoria": "Accesorios"
  }
```
En este ejemplo, la propiedad "codigo" tiene un valor de "8",
la propiedad "nombre" tiene un valor de "Disco Duro Externo",
la propiedad "precio": tiene un valor asignado de "99.99" y
la propiedad "categoria" un valor de "Accesorios".

Al ejecutar el método, se creará un nuevo objeto con los atributos declarados en el ***Body***.

### 'Read'
### El método GET
Mediante este método podemos realizar varias acciones de lectura:
-  Ver el listado completo de artículos.
-  Buscar uno o varios artículo/s por su **nombre** o parte del mismo.
-  Buscar uno o varios artículos por la **categoria** o parte de ella.
-  Buscar un articulo específico por su **codigo**.
-  Buscar los artículos que superen un **precio** determinado.

(Véase [Tabla URL](#tabla-url))


### 'Update'
### El método PUT
El método pus es utilizado en esta API para modificar únicamente el precio de un producto existente.

Se debe pasar por parámetro tanto la colección como el código del producto a modificar. (Vease [Tabla URL](#tabla-url))

La modificación del precio requiere que se cargue en el ***Body*** de la petición el precio nuevo del producto en cuestión.

#### El body de la petición PUT
En el ***Body***  del método, escribir entre corchetes el precio nuevo del producto.
En el siguiente ejemplo el precio nuevo es 300:

``` js
[300]

```
Al ejecutar el método se modifica el precio de dicho producto.

### 'Delete'
### El método DELETE
Este método nos permite eliminar un artículo del listado "computacion".
Debe pasarse por parámetro el listado y el **codigo** del producto que se desea eliminar.
(Vease [Tabla URL](#tabla-url))

## Ejemplos de uso

 ### Ejemplo de uso del método **POST**
 Supongamos que queremos dar de alta un nuevo producto con las siguientes características:

 codigo: 18,
 nombre: "Disco Sólido SSD Patriot 512G",
 precio: 299.99,
 categoria: "Accesorios"

 Para ello, utilizamos el método **POST** para realizar el pedido a la URL.
 
 La URL a utilizar será: http://localhost:3008/computacion 
 
  (Vease [Tabla URL](#tabla-url))

 En el ***Body*** de la petición declaramos las propiedades del objeto en el formato correspondiente:

 ```js
   {
     "codigo": 18,
     "nombre": "Disco Sólido SSD Patriot 512G",
     "precio": 299.99,
     "categoria": "Accesorios"
   }
 ```
 Entonces podemos ejecutar la petición y crear un nuevo artículo que quedará registrado en la base de datos.

 ### Ejemplo de uso del método **GET**
 Si queremos acceder al listado de todos los artículos registrados en la colección "computación" en la base de datos, utilizaremos el método **GET**.
 
 La URL correspondiente a dicha consulta será: http://localhost:3008/computacion   
 (Vease [Tabla URL](#tabla-url))
 
 Este método no lleva contenido en el ***Body***.
 
 Al ejecutarlo, se desplegará el listado de los artículos en formato JSON, como un Array de objetos.

 ```js
 [
   {
     "_id": "64aeba85e34293ca9486be68",
     "codigo": 1,
     "nombre": "Desktop Gaming",
     "precio": 999.99,
     "categoria": "Desktop"
   },
  {
    "_id": "64aeba85e34293ca9486be69",
    "codigo": 2,
    "nombre": "Laptop Ultrabook",
    "precio": 1299.99,
    "categoria": "Portátiles"
  },
  {
    "_id": "64aeba85e34293ca9486be6a",
    "codigo": 3,
    "nombre": "Teclado Mecánico",
    "precio": 89.99,
    "categoria": "Accesorios"
  },
  {
    "_id": "64aeba85e34293ca9486be6b",
    "codigo": 4,
    "nombre": "Impresora Multifuncional",
    "precio": 199.99,
    "categoria": "Impresoras"
  },
  ...(etc)
 ]
 ```
 Otro ejemplo de este método es el buscar datos por un **precio** mayor o igual al que pasemos por parámetro.

 Aquí, el filtro de búsqueda en la base de datos se vale del operador **$get** el cual nos permite  buscar documentos con valores de **precio** mayores o iguales a un número dado.
 
 Valiéndonos de la petición **GET**, en este ejemplo, queremos buscar todos los artículos cuyo **precio** sea mayor o igual a 800, entonces enviamos la siguiente URL: http://localhost:3008/computacion/precio/800

 Luego ejecutamos la petición.

 La respuesta del sistema:

 ``` js
 [
  {
    "_id": "64aeba85e34293ca9486be68",
    "codigo": 1,
    "nombre": "Desktop Gaming",
    "precio": 999.99,
    "categoria": "Desktop"
  },
  {
    "_id": "64aeba85e34293ca9486be69",
    "codigo": 2,
    "nombre": "Laptop Ultrabook",
    "precio": 1299.99,
    "categoria": "Portátiles"
  },
  {
    "_id": "64aeba85e34293ca9486be72",
    "codigo": 11,
    "nombre": "All-in-One PC",
    "precio": 899.99,
    "categoria": "Desktop"
  },
  {
    "_id": "64aeba85e34293ca9486be7d",
    "codigo": 22,
    "nombre": "Laptop Gamer",
    "precio": 1499.99,
    "categoria": "Portátiles"
  }
]

 ```

 ### Ejemplo de uso del método **PUT**
 Supongamos que queremos modificar el precio de un determinado artículo. El **código** de dicho artículo es 5 y el precio nuevo es de 450.
 Haremos uso del método **PUT** para llevar a cabo dicha tarea.

 La URL correspondiente será: |http://localhost:3008/computacion/5          
 (Vease [Tabla URL](#tabla-url))
 
 En el ***Body** de la petición escribiremos el precio nuevo entre corchetes:
 ``` js
 [450]

 ```
 Al ejecutar la petición se modificará el precio del artículo cuyo código es 5 en la base de datos.

 ### Ejemplo de uso del método **DELETE**
 Para eliminar un registro específico existente en la colección "computacion" recurriremos al método **DELETE**.
 Supongamos que el **código** del artículo que deseamos eliminar es 12.
 Entonces, la URL correspondiente será: http://localhost:3008/computacion/12
 
 Este método no lleva contenido en el ***Body***.
 
 Al ejecutar la petición, se eliminará permanentemente el registro cuyo **código** es 12.


## Conexión a MongoDB
La conexión con la base de datos de MongoDB se declara en el archivo .env, cuyo contenido se muestra a continuación:

``` js
PORT=3008
MONGODB_URLSTRING=mongodb+srv://spalamariano:******@cluster8.hv3icxv.mongodb.net/

```
Aquí observamos dos declaraciones, la primera, **PORT**, define el puerto local (3008 en este caso) por donde se enviarán las rutas y las peticiones CRUD, así como también se recibirán las respuestas de las peticiones. Este puerto hace las veces de servidor web.

La segunda, **MONGODB_URLSTRING** contiene la ruta para la conección con la base de datos de MongoDB.


## Diagrama de secuencia
``` mermaid
sequenceDiagram
    participant User
    participant Api
     participant DDBB
    User->>+Api: Carga de Datos y peticiones
    Api-->>+DDBB: CRUD y Acceso a datos
    DDBB-->>+Api: Respuesta (datos)
    Api->>+User: Mostrar datos
```


## Diagrama de flujo
``` mermaid
graph TD;
    HTTP-->REQUEST;
    REQUEST-->localhost;
    localhost-->MongoDB;
    MongoDB-->JSON;
    JSON--->localhost;
    localhost-->RESPONSE;
    RESPONSE-->HTTP;
```


## Listado de Errores
- Error: "**Error en el formato del elemento a ...**" ; error en el formato de los datos del artículo afectado.
- Error: "**Error de conexion a DB**"  ; error al establecer la conexion con la base de datos MongoDB.
- Error: "**Error al acceder a computacion**" ; error del sistema al acceder a la colección "computacion" en la base de datos.
- Error: "**No existen coincidencias**" ; el sistema no encuentra coincidencia entre el **código** o el **precio** pasado por parámetro y el **código** o el **precio**  de un artículo registrado en la base de datos.

