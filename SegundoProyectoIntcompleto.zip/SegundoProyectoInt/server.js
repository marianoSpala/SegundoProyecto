const express = require ('express');
const { connectToMongoDB, disconnectFromMongoDB } = require ('./src/mongodb');
const app = express();
const PORT = process.env.PORT || 3000;

//Middleware
app.use(express.json());

app.use((req, res, next) => {
    res.header("Content-Type", "application/json; charset=utf-8");
    next();
});

//Rutas

app.get('/', (req, res) => {
    res.status(200).send('Bienvenido a la API Segundo Proyecto Integrador!!!');
});

app.get('/computacion', async (req, res) => {
    try{
    const client = await connectToMongoDB();
    if (!client) {
        res.status(500).send('Error de conexion a DB');
        return;
    }
    const db = client.db('computacion');
    const autos = await db.collection('computacion').find().toArray();
    autos.sort((x, y) => x.codigo - y.codigo);
    
    await disconnectFromMongoDB();
          res.json(autos);
       }
       catch{
        disconnectFromMongoDB();
         res.status(500).send('Error al acceder a computacion');
        return;
       }
});

app.get('/computacion/:codigo', async (req, res) => {
    try{
    const client = await connectToMongoDB();
    if (!client) {
        res.status(500).send('Error de conexion a DB');
        return;
    }
    const db = client.db('computacion');
    const collection = db.collection('computacion');
    const autoId = parseInt(req.params.codigo) || 0;
    let auto = [];   
    auto = await collection.findOne({codigo: autoId});
    
    await disconnectFromMongoDB();
    if (auto === null)
    {
        res.status(404).json([{codigo:"Error", descripcion:"No existen coincidencias"}]);
    }
    else{
    auto.length>0
    ? res.status(404).json([{codigo:"Error", descripcion:"No existen coincidencias"}])
    : res.json(auto);
        }
    }
    catch{ disconnectFromMongoDB();
        res.status(500).send('Error al acceder a computacion');
    return;}
});

app.get('/computacion/categoria/:categoria', async (req, res) => {
    try{
    const client = await connectToMongoDB();
    if (!client) {
        res.status(500).send('Error de conexion a DB');
        return;
    }
    const db = client.db('computacion');
    const autoNom = req.params.categoria.trim().toLowerCase();
    let autoBus = RegExp(autoNom, "i");
    const auto = await db.collection('computacion').find({categoria: autoBus}).toArray();

    await disconnectFromMongoDB();
    auto.length>0
    ? res.json(auto)
    : res.status(404).json([{categoria:"Error", descripcion:"No existen coincidencias"}]);
    }
    catch{ 
        disconnectFromMongoDB();
        res.status(500).send('Error al acceder a computacion');
    return;}
});

app.get('/computacion/nombre/:nombre', async (req, res) => {
    try{
    const client = await connectToMongoDB();
    if (!client) {
        res.status(500).send('Error de conexion a DB');
        return;
    }
    const db = client.db('computacion');
    const autoNom = req.params.nombre.trim().toLowerCase();
    let autoBus = RegExp(autoNom, "i");
    const auto = await db.collection('computacion').find({nombre: autoBus}).toArray();

    await disconnectFromMongoDB();
    auto.length>0
    ? res.json(auto)
    : res.status(404).json([{nombre:"Error", descripcion:"No existen coincidencias"}]);
    }
    catch{ 
        disconnectFromMongoDB();
        res.status(500).send('Error al acceder a computacion');
    return;}
});

app.get('/computacion/precio/:precio', async (req, res) => {
    try{
    const client = await connectToMongoDB();
    if (!client) {
        res.status(500).send('Error de conexion a DB');
        return;
    }
    const db = client.db('computacion');
    const autoPre = parseInt(req.params.precio) || 0;
    const auto = await db.collection('computacion').find({precio: {$gte: autoPre}}).toArray();
   
    auto.length>0
    ? res.json(auto)
    : res.status(404).json([{precio:"Error", descripcion:"No existen coincidencias"}]);
    }
    catch{       
        res.status(500).send('Error al acceder a computacion');
    return;}
    finally{
        await disconnectFromMongoDB();
    }
});

app.post('/computacion', async (req, res) => {
    const nuevoArt = req.body;
    try{
    if (nuevoArt === undefined){
        res.status(400).send("Error en el elemento a crear");
    }

    const client = await connectToMongoDB();
    if (!client) {
        res.status(500).send('Error de conexion a DB');
        return;
    }

    const db = client.db('computacion');
    const collection = db.collection('computacion');
    await collection.insertOne(nuevoArt).then(() => {
        console.log('Nuevo articulo creado.');
        res.status(201).send(nuevoArt);
    });
    }
    catch (error) {
        res.status(500).send('Error al acceder a computacion');
        return;
    } 
    finally{
       await disconnectFromMongoDB();
    }
});

app.put('/computacion/:codigo', async (req, res) => {
    try{
        const nuevoArt = parseInt(req.params.codigo);
        const nuevosDatos = req.body;
    if (!nuevosDatos){
        res.status(400).send("Error en el formato del elemento a modificar");
    }

    const client = await connectToMongoDB();
    if (!client) {
        res.status(500).send('Error de conexion a DB');
        return;
    }
    
    const db = client.db('computacion');
    const collection = db.collection('computacion');
    await collection.updateOne({codigo: nuevoArt}, {$set: {precio: parseInt(nuevosDatos)}}).then(() => {
        console.log('Articulo modificado.');
        res.status(200).send(nuevosDatos);
    });
    }
    catch (error) {
        res.status(500).send('Error al acceder a computacion');
        return;
    } 
    finally{
       await disconnectFromMongoDB();
    }
});

app.delete('/computacion/:codigo', async (req, res) => {
    const eliminaArt = parseInt(req.params.codigo);
    try{
    if (!eliminaArt){
        res.status(400).send("Error en el elemento a eliminar");
    }

    const client = await connectToMongoDB();
    if (!client) {
        res.status(500).send('Error de conexion a DB');
        return;
    }
    
    const db = client.db('computacion');
    const collection = db.collection('computacion');
    await collection.deleteOne({codigo: eliminaArt}).then(() => {
        res.status(204).send("Articulo eliminado.");
        console.log('Articulo eliminado.');
    });
    }
    catch (error) {
        res.status(500).send('Error al acceder a computacion');
        return;
    } 
    finally{
       await disconnectFromMongoDB();
    }
});





app.get('*', (req, res) => {
    res.status(404).send('Ups! El sitio que buscas no existe.')
  });
 
 app.listen(PORT, () => {
     console.log(`Servidor escuchando en el puerto ${PORT}`);
 });